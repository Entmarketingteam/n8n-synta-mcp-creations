# LTK (LikeToKnow.it) Integration

**Status**: ✅ Working

---

## 🎯 Overview

LTK is an affiliate marketing platform for fashion/lifestyle creators. They don't provide a public API, but we've reverse-engineered their internal API using HAR analysis.

### Key Facts
- **Company**: rewardStyle
- **Dashboard**: https://www.shopltk.com/creator
- **Auth Provider**: Auth0
- **Auth Type**: OAuth2 PKCE
- **Token Lifetime**: 8 hours (28800 seconds)

---

## 🔐 Authentication

### Flow
```
1. Initial Auth (Browser Required)
   └─▶ Login at shopltk.com
   └─▶ PKCE flow with Auth0
   └─▶ Receive access_token + refresh_token

2. Token Refresh (Automated)
   └─▶ POST to token endpoint
   └─▶ Receive NEW tokens (both rotate!)
   └─▶ Store in Airtable
```

### Token Endpoint
```
POST https://creator-auth.shopltk.com/oauth/token
Content-Type: application/x-www-form-urlencoded

grant_type=refresh_token
&client_id={CLIENT_ID}
&refresh_token={CURRENT_REFRESH_TOKEN}
```

### Response
```json
{
  "access_token": "eyJhbGc...",
  "refresh_token": "v1.McH...",
  "expires_in": 28800,
  "token_type": "Bearer"
}
```

### ⚠️ Important Notes
- **Tokens ROTATE**: Each refresh gives you a NEW refresh_token
- Old refresh token is immediately invalidated
- Must save both tokens atomically before using

---

## 📊 API Endpoints

### Base URL
```
https://api-gateway.rewardstyle.com
```

### Authentication Header
```
Authorization: Bearer {access_token}
```

### Discovered Endpoints

| Endpoint | Method | Purpose |
|----------|--------|---------|
| `/api/v1/creators/{id}/analytics` | GET | Performance metrics |
| `/api/v1/creators/{id}/commissions` | GET | Earnings data |
| `/api/v1/creators/{id}/products/top` | GET | Top products |
| `/api/v1/creators/{id}/links` | GET | Link management |

### Get Analytics
```bash
curl -X GET "https://api-gateway.rewardstyle.com/api/v1/creators/{CREATOR_ID}/analytics?start_date=2024-01-01&end_date=2024-01-31" \
  -H "Authorization: Bearer {ACCESS_TOKEN}" \
  -H "Content-Type: application/json"
```

### Get Commissions
```bash
curl -X GET "https://api-gateway.rewardstyle.com/api/v1/creators/{CREATOR_ID}/commissions?status=approved&page=1&limit=50" \
  -H "Authorization: Bearer {ACCESS_TOKEN}"
```

---

## 🔧 Configuration

### Environment Variables
```bash
# Add to .env
LTK_CLIENT_ID=jGa...  # From HAR analysis
LTK_CREATOR_ID=...    # Your creator ID
```

### Airtable Schema
```
Table: LTK_Tokens

Fields:
├── platform: "ltk" (Single Line Text)
├── creator_id: (Single Line Text)
├── access_token: (Long Text)
├── refresh_token: (Long Text)
├── expires_at: (DateTime)
├── status: active | error (Single Select)
├── last_refreshed: (DateTime)
└── error_message: (Long Text)
```

---

## 📁 Files in This Directory

```
platforms/ltk/
├── README.md                 # This file
├── auth/
│   ├── token-refresh.json    # n8n workflow for token refresh
│   ├── initial-auth.js       # Browserbase script for initial login
│   └── har-analysis.md       # Notes from HAR file analysis
├── data/
│   ├── get-analytics.json    # n8n workflow for analytics
│   ├── get-commissions.json  # n8n workflow for commissions
│   └── endpoints.md          # Full API documentation
└── config/
    ├── airtable-schema.json  # Airtable table schema
    └── env-vars.md           # Required environment variables
```

---

## 🚀 Deployed Workflows

| Workflow | n8n ID | Schedule | Status |
|----------|--------|----------|--------|
| LTK Token Rotation | `a9gH2UthD2w239iv` | Every 8 hours | ✅ Active |
| Run LTK Reports | `2Rr3f3YCgy3OIZ...` | On token refresh | ✅ Active |

---

## 🔄 Token Refresh Workflow

### Architecture
```
┌─────────────┐     ┌─────────────────────┐
│ Every 8 Hrs │────▶│ Read Token from     │
│ + Manual    │     │ Airtable            │
└─────────────┘     └──────────┬──────────┘
                               │
                               ▼
                    ┌─────────────────────┐
                    │ POST /oauth/token   │
                    │ grant_type=refresh  │
                    └──────────┬──────────┘
                               │
                               ▼
                    ┌─────────────────────┐
                    │ Token Refreshed?    │
                    └──────────┬──────────┘
                          │         │
                       TRUE       FALSE
                          │         │
                          ▼         ▼
                   ┌──────────┐ ┌──────────────┐
                   │ Save New │ │ Mark Error + │
                   │ Tokens   │ │ Send Alert   │
                   └────┬─────┘ └──────────────┘
                        │
                        ▼
                   ┌──────────────┐
                   │ Trigger LTK  │
                   │ Reports      │
                   └──────────────┘
```

---

## 🐛 Troubleshooting

### "invalid_grant" Error
**Cause**: Refresh token expired or was already used
**Solution**: 
1. Login manually at shopltk.com
2. Capture new tokens from browser DevTools
3. Update Airtable with fresh tokens

### "Unauthorized" on API Calls
**Cause**: Access token expired
**Solution**: Check if token refresh workflow is running

### Tokens Not Saving
**Cause**: Airtable field name mismatch
**Solution**: Verify field names match exactly (case-sensitive)

---

## 📝 HAR Analysis Notes

The initial auth flow was captured and analyzed. Key discoveries:

1. **Auth0 Integration**: LTK uses Auth0 for identity
2. **PKCE Required**: Initial auth needs browser for PKCE flow
3. **Token Rotation**: Both tokens rotate on each refresh
4. **No Client Secret**: Only client_id needed (public client)

See `auth/har-analysis.md` for full details.

---

## 🔗 Related Resources

- [n8n Workflow](https://entagency.app.n8n.cloud/workflow/a9gH2UthD2w239iv)
- [Airtable Base](https://airtable.com/appXXX)
- [LTK Creator Dashboard](https://www.shopltk.com/creator)
