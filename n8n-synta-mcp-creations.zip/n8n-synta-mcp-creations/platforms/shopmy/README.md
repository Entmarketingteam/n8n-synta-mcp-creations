# ShopMy Integration

**Status**: 🔄 In Progress

---

## 🎯 Overview

ShopMy is an affiliate marketing platform for creators. This integration is currently being developed.

### Key Facts
- **Dashboard**: https://app.shopmy.us
- **Auth Provider**: TBD (need HAR analysis)
- **Auth Type**: Suspected OAuth2
- **Token Lifetime**: TBD

---

## 📋 TODO Checklist

### Phase 1: Discovery
- [ ] Login to ShopMy dashboard
- [ ] Capture HAR file of login flow
- [ ] Capture HAR file of dashboard/data pages
- [ ] Save HAR files to `har-analysis/samples/`

### Phase 2: Analysis
- [ ] Run auth flow analysis (use prompts in `har-analysis/prompts/`)
- [ ] Document token endpoint
- [ ] Document refresh mechanism
- [ ] Identify API endpoints

### Phase 3: Implementation
- [ ] Create token refresh workflow
- [ ] Test with manual trigger
- [ ] Set up Airtable storage
- [ ] Configure scheduled refresh

### Phase 4: Data Extraction
- [ ] Document analytics endpoints
- [ ] Create data sync workflows
- [ ] Add to unified dashboard

---

## 🔐 Authentication

### Suspected Flow
Based on similar platforms, ShopMy likely uses:
- OAuth2 (standard or PKCE)
- JWT access tokens
- Refresh token mechanism

### To Discover
```yaml
# Fill in after HAR analysis
token_endpoint: "???"
client_id: "???"
grant_type: "???"
token_lifetime: "???"
refresh_rotates: ???
```

---

## 📊 API Endpoints

### To Discover
Capture HAR while browsing:
- Dashboard page
- Analytics/reports page
- Earnings/commissions page
- Product performance page

### Expected Endpoints
```yaml
# Fill in after HAR analysis
base_url: "???"
endpoints:
  - path: "???"
    method: GET
    purpose: Analytics
  - path: "???"
    method: GET
    purpose: Commissions
```

---

## 📁 Files in This Directory

```
platforms/shopmy/
├── README.md                 # This file
├── auth/
│   ├── token-refresh.json    # 📋 TODO
│   ├── initial-auth.js       # 🔄 Started (browserbase runner)
│   └── har-analysis.md       # 📋 TODO
├── data/
│   └── endpoints.md          # 📋 TODO
└── config/
    └── airtable-schema.json  # 📋 TODO
```

---

## 🔗 Resources

- [ShopMy Dashboard](https://app.shopmy.us)
- [Existing browserbase runner](../../shopmy-browserbase-runner/)

---

## 📝 Notes

Add any notes from initial investigation here:

```
[Your notes here]
```
