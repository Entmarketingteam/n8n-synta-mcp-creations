# Mavely Integration

**Status**: 📋 Planned

---

## 🎯 Overview

Mavely is an affiliate marketing platform. This integration is planned but not yet started.

### Key Facts
- **Dashboard**: https://app.mavely.com (or similar - need to verify)
- **Auth Provider**: Unknown
- **Auth Type**: Unknown (possibly API key?)
- **Token Lifetime**: Unknown

---

## 📋 TODO Checklist

### Phase 1: Discovery
- [ ] Verify dashboard URL
- [ ] Check if API key is available in settings
- [ ] If no API key, capture HAR file of login
- [ ] Capture HAR file of dashboard/data pages

### Phase 2: Analysis
- [ ] Determine auth type (API key vs OAuth vs Session)
- [ ] Document authentication method
- [ ] Identify API endpoints

### Phase 3: Implementation
- [ ] Create auth workflow (if needed)
- [ ] Test authentication
- [ ] Set up storage

### Phase 4: Data Extraction
- [ ] Document analytics endpoints
- [ ] Create data sync workflows
- [ ] Add to unified dashboard

---

## 🔐 Authentication

### Investigation Questions
1. Does Mavely provide API keys in dashboard settings?
2. If OAuth, what type (standard, PKCE)?
3. Session-based auth?

### To Discover
```yaml
# Fill in after investigation
auth_type: "???"  # api_key | oauth2 | oauth2_pkce | session
token_endpoint: "???"
credentials_needed: ???
```

---

## 💡 Initial Investigation

Before capturing HAR files, check:

1. **Settings/Developer Page**: Look for API keys or developer options
2. **Documentation**: Check if they have any API docs
3. **Network Tab**: Quick look at what requests the dashboard makes

If they have API keys, this will be the **easiest** integration!

---

## 📊 API Endpoints

### To Discover
```yaml
# Fill in after HAR analysis or API docs
base_url: "???"
endpoints:
  - path: "???"
    method: GET
    purpose: Analytics
  - path: "???"
    method: GET
    purpose: Commissions
```

---

## 📁 Files in This Directory

```
platforms/mavely/
├── README.md                 # This file
├── auth/
│   └── har-analysis.md       # 📋 TODO
├── data/
│   └── endpoints.md          # 📋 TODO
└── config/
```

---

## 📝 Notes

Add any notes from initial investigation here:

```
[Your notes here]
```
