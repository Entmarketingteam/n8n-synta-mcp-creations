# Amazon Associates Integration

**Status**: 📋 Planned (Complex)

---

## ⚠️ Complexity Warning

Amazon Associates is the **most difficult** platform to automate due to:
- No OAuth API
- Aggressive bot detection
- Mandatory 2FA for many accounts
- Session cookies expire unpredictably
- Constant UI changes

---

## 🎯 Overview

Amazon Associates is Amazon's affiliate program. They provide a Product Advertising API for product data, but **no API for earnings/reports**.

### Key Facts
- **Dashboard**: https://affiliate-program.amazon.com
- **Auth Type**: Session Cookie (no OAuth)
- **Session Lifetime**: ~24 hours (varies)
- **2FA**: Often required
- **Bot Detection**: Aggressive

---

## 🔐 Authentication Strategy

### The Challenge
```
Traditional Approach (DOESN'T WORK):
┌──────────────┐     ┌──────────────┐
│ HTTP Request │────▶│ Login Page   │ ❌ Bot detected
│ with creds   │     │              │
└──────────────┘     └──────────────┘

Required Approach:
┌──────────────┐     ┌──────────────┐     ┌──────────────┐
│ Real Browser │────▶│ Login Page   │────▶│ Handle 2FA   │
│ (Browserbase)│     │ + CAPTCHA    │     │ if prompted  │
└──────────────┘     └──────────────┘     └──────────────┘
         │
         ▼
┌──────────────┐
│ Extract      │
│ Cookies      │
└──────────────┘
```

### Potential Solutions

#### Option 1: Browserbase Persistent Session
Keep a browser session alive 24/7:
```javascript
// Pros: Most reliable
// Cons: Expensive, still may get logged out

const session = await browserbase.createPersistentSession();
// Session stays alive between runs
```

#### Option 2: Cookie Extraction + Refresh
1. Login manually once
2. Extract session cookies
3. Use cookies for API calls
4. Re-login when session expires

#### Option 3: Email 2FA Automation
1. Browser automation for login
2. Check email for 2FA code
3. Submit 2FA code automatically
4. Extract cookies

#### Option 4: Manual Fallback
1. Attempt automated login
2. If 2FA/CAPTCHA detected, send alert
3. Human completes login
4. Continue with automation

---

## 📊 What We Can Extract

### With Session Cookies
| Data | Endpoint/Method | Difficulty |
|------|-----------------|------------|
| Earnings Summary | Scrape dashboard | Medium |
| Order Reports | Download CSV | Medium |
| Link Performance | Scrape reports page | Hard |
| Product Clicks | Scrape reports page | Hard |

### With Product Advertising API (Separate)
- Product details
- Prices
- Availability
- Images

Note: PA-API doesn't include earnings data!

---

## 📋 TODO Checklist

### Phase 1: Research
- [ ] Capture HAR file of login flow
- [ ] Document all required cookies
- [ ] Identify bot detection triggers
- [ ] Test session cookie lifetime

### Phase 2: Browserbase Script
- [ ] Create login automation
- [ ] Handle 2FA scenarios
- [ ] Cookie extraction
- [ ] Test persistence

### Phase 3: n8n Integration
- [ ] Workflow to trigger browser login
- [ ] Store cookies in Airtable
- [ ] Refresh workflow
- [ ] Error/alert handling

### Phase 4: Data Extraction
- [ ] Earnings dashboard scraping
- [ ] Report CSV download
- [ ] Data parsing workflows

---

## 🔧 Required Infrastructure

### Browserbase Setup
```javascript
// Persistent session for Amazon
const session = await browserbase.sessions.create({
  projectId: process.env.BROWSERBASE_PROJECT_ID,
  browserSettings: {
    fingerprint: {
      // Use consistent fingerprint to avoid detection
      devices: ["desktop"],
      locales: ["en-US"],
      operatingSystems: ["macos"]
    }
  },
  keepAlive: true,
  timeout: 86400000 // 24 hours
});
```

### Cookies to Capture
```yaml
required_cookies:
  - name: "session-id"
    domain: ".amazon.com"
  - name: "session-token"
    domain: ".amazon.com"
  - name: "x-main"
    domain: ".amazon.com"
  - name: "at-main"
    domain: ".amazon.com"
  - name: "sess-at-main"
    domain: ".amazon.com"
```

---

## 📁 Files in This Directory

```
platforms/amazon-associates/
├── README.md                   # This file
├── auth/
│   ├── session-refresh.js      # 📋 TODO - Browserbase script
│   ├── cookie-extractor.js     # 📋 TODO - Extract cookies
│   └── har-analysis.md         # 📋 TODO
├── data/
│   ├── scrape-earnings.js      # 📋 TODO - Dashboard scraper
│   ├── download-reports.js     # 📋 TODO - CSV download
│   └── endpoints.md            # 📋 TODO
└── config/
    └── cookie-schema.json      # 📋 TODO
```

---

## 💡 Alternative Approaches

### 1. Amazon PA-API + Manual Earnings
- Use PA-API for product data (has official API)
- Export earnings manually monthly
- Best for low-volume tracking

### 2. Third-Party Tools
- Tools like Affilimate aggregate affiliate data
- May already solve this problem
- Worth investigating before building custom

### 3. Email Reports
- Amazon sends weekly/monthly email reports
- Could parse emails instead of scraping
- More reliable than browser automation

---

## 📝 Notes

```
[Add investigation notes here]
```

---

## 🔗 Resources

- [Amazon Associates Dashboard](https://affiliate-program.amazon.com)
- [Product Advertising API](https://webservices.amazon.com/paapi5/documentation/)
- [Browserbase Docs](https://docs.browserbase.com)
