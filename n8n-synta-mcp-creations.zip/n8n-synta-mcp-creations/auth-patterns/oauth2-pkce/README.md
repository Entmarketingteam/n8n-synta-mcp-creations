# OAuth2 PKCE Token Refresh Pattern

**Reusable pattern for platforms using OAuth2 with PKCE (Proof Key for Code Exchange).**

---

## 🎯 When to Use

Use this pattern when the platform:
- Redirects to `/authorize` or `/oauth/authorize` for login
- Uses `code_verifier` and `code_challenge` parameters
- Returns `access_token` + `refresh_token`
- Requires token refresh (tokens expire)

**Examples**: LTK, ShopMy, many mobile-first apps

---

## 📋 Required Configuration

Before using this template, you need:

```yaml
# config.yaml
platform_name: "your_platform"

auth:
  token_endpoint: "https://auth.platform.com/oauth/token"
  client_id: "your_client_id"
  grant_type: "refresh_token"
  
tokens:
  access_lifetime_seconds: 28800  # 8 hours typical
  refresh_rotates: true  # Does refresh token change each time?
  
storage:
  type: "airtable"
  base_id: "appXXXXXXXXXXXXX"
  table_name: "Platform_Tokens"
  
schedule:
  cron: "0 */8 * * *"  # Run before token expires
  
notifications:
  on_error:
    type: "slack"
    webhook: "${SLACK_WEBHOOK_URL}"
```

---

## 🔧 Template Variables

Replace these placeholders in the workflow JSON:

| Variable | Description | Example |
|----------|-------------|---------|
| `{{PLATFORM_NAME}}` | Human-readable name | "LTK" |
| `{{TOKEN_ENDPOINT}}` | OAuth token URL | "https://creator-auth.shopltk.com/oauth/token" |
| `{{CLIENT_ID}}` | OAuth client ID | "jGa..." |
| `{{AIRTABLE_BASE_ID}}` | Your Airtable base | "appXXX" |
| `{{TABLE_NAME}}` | Tokens table name | "LTK_Tokens" |
| `{{REFRESH_HOURS}}` | Hours between refresh | "8" |
| `{{DOWNSTREAM_WORKFLOW_ID}}` | Workflow to trigger on success | "abc123" |

---

## 📊 Airtable Schema

Create this table structure:

```
Table: {{PLATFORM_NAME}}_Tokens

Fields:
├── platform (Single Line Text) - Platform identifier
├── creator_id (Single Line Text) - User/creator ID
├── access_token (Long Text) - Current access token
├── refresh_token (Long Text) - Current refresh token  
├── expires_at (DateTime) - Token expiration time
├── status (Single Select) - active | error | expired
├── last_refreshed (DateTime) - Last successful refresh
├── error_message (Long Text) - Last error if any
└── record_id (Formula) - RECORD_ID() for easy lookup
```

---

## 🔄 Workflow Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                   TOKEN REFRESH WORKFLOW                        │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  TRIGGERS                                                       │
│  ┌──────────────┐    ┌──────────────┐                          │
│  │ Every {{N}}  │    │ Manual Test  │                          │
│  │ Hours        │    │              │                          │
│  └──────┬───────┘    └──────┬───────┘                          │
│         │                   │                                   │
│         └─────────┬─────────┘                                   │
│                   │                                             │
│                   ▼                                             │
│  READ TOKEN   ┌──────────────────┐                             │
│               │ Airtable: Search │                             │
│               │ platform = "X"   │                             │
│               │ status = active  │                             │
│               └────────┬─────────┘                             │
│                        │                                        │
│                        ▼                                        │
│  REFRESH      ┌──────────────────┐                             │
│               │ HTTP POST        │                             │
│               │ {{TOKEN_ENDPOINT}}│                             │
│               │ grant_type=refresh│                            │
│               └────────┬─────────┘                             │
│                        │                                        │
│                        ▼                                        │
│  CHECK        ┌──────────────────┐                             │
│               │ IF: access_token │                             │
│               │ exists?          │                             │
│               └────────┬─────────┘                             │
│                   │         │                                   │
│                TRUE       FALSE                                 │
│                   │         │                                   │
│                   ▼         ▼                                   │
│           ┌──────────┐ ┌──────────────┐                        │
│  SUCCESS  │ Format   │ │ Mark Error   │  ERROR                 │
│           │ for Save │ │ in Airtable  │                        │
│           └────┬─────┘ └──────┬───────┘                        │
│                │              │                                 │
│                ▼              ▼                                 │
│           ┌──────────┐ ┌──────────────┐                        │
│           │ Update   │ │ Send Alert   │                        │
│           │ Airtable │ │ to Slack     │                        │
│           └────┬─────┘ └──────────────┘                        │
│                │                                                │
│                ▼                                                │
│           ┌──────────┐                                         │
│  TRIGGER  │ Execute  │                                         │
│           │ Workflow │                                         │
│           └──────────┘                                         │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## 📝 Implementation Notes

### Token Rotation Handling

⚠️ **Critical**: Many OAuth2 PKCE implementations rotate the refresh token on each use. This means:

1. You get a NEW refresh_token in the response
2. The OLD refresh_token is immediately invalidated
3. You MUST save the new refresh_token before using access_token

```javascript
// Correct order of operations:
1. Make refresh request
2. Check for success
3. IMMEDIATELY save new refresh_token to Airtable
4. Then use access_token for API calls
5. Then trigger downstream workflows

// If you skip step 3 and the workflow fails at step 4,
// you've lost the new refresh_token and can't recover!
```

### Error Handling

Handle these scenarios:

| Error | Cause | Action |
|-------|-------|--------|
| `invalid_grant` | Refresh token expired/revoked | Mark error, require manual re-auth |
| `invalid_client` | Client ID wrong | Check configuration |
| Network timeout | API down | Retry with backoff |
| 429 Rate Limited | Too many requests | Wait and retry |

### Scheduling

Set refresh schedule to run BEFORE token expires:

| Token Lifetime | Recommended Schedule |
|----------------|---------------------|
| 1 hour | Every 45 minutes |
| 8 hours | Every 6-7 hours |
| 24 hours | Every 20-22 hours |

---

## 🚀 Deployment Steps

1. **Create Airtable table** with schema above
2. **Add initial tokens** manually (from browser auth)
3. **Import workflow** to n8n
4. **Update variables** in workflow
5. **Test with manual trigger**
6. **Activate workflow**

---

## ✅ Testing Checklist

Before activating:

- [ ] Manual trigger works
- [ ] Tokens saved correctly to Airtable
- [ ] Both access AND refresh tokens updated
- [ ] expires_at calculated correctly
- [ ] Error path sends notification
- [ ] Downstream workflow triggers

---

## 🔗 Files in This Pattern

```
auth-patterns/oauth2-pkce/
├── README.md              # This file
├── workflow.json          # n8n workflow template
└── config-schema.json     # Configuration schema
```
