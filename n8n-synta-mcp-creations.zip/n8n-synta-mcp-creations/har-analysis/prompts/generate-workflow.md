# Generate n8n Workflow

**LLM Prompt for creating complete n8n workflow JSON from auth/endpoint specifications.**

---

## Usage

After you have:
1. Auth pattern documented (from `analyze-auth-flow.md`)
2. Endpoints cataloged (from `extract-endpoints.md`)

Use this prompt to generate the actual n8n workflow JSON.

---

## Prompt

```markdown
You are an expert n8n workflow builder. Create a complete, production-ready n8n workflow JSON based on the following specifications.

## Workflow Requirements

**Name**: [e.g., "LTK Token Rotation"]
**Purpose**: [e.g., "Automatically refresh OAuth2 tokens before expiration"]

## Auth Specification

[PASTE YOUR AUTH SPEC FROM analyze-auth-flow.md OUTPUT]

## Endpoints to Use

[PASTE RELEVANT ENDPOINTS FROM extract-endpoints.md OUTPUT]

## Storage Configuration

```yaml
token_storage:
  type: airtable  # or google_sheet
  base_id: "appXXXXXXXXXXXXXX"
  table_name: "Platform_Tokens"
  fields:
    platform: "single_line_text"
    access_token: "long_text"
    refresh_token: "long_text"
    expires_at: "datetime"
    status: "single_select"  # active, error, expired
    last_updated: "datetime"
```

## Trigger Requirements

```yaml
triggers:
  - type: schedule
    cron: "0 */8 * * *"  # Every 8 hours
    enabled: true
  - type: manual
    purpose: "Testing"
```

## Error Handling Requirements

```yaml
error_handling:
  on_refresh_failure:
    - mark_status_error_in_storage: true
    - send_notification: true
    - notification_channel: slack  # or email
  retry:
    attempts: 3
    delay_seconds: 30
```

## Success Actions

```yaml
on_success:
  - save_new_tokens: true
  - trigger_downstream_workflows:
      - workflow_id: "abc123"
        name: "Run LTK Reports"
  - log_to_sheet: false
```

---

## Required Output Format

Generate a COMPLETE n8n workflow JSON that:

1. **Is valid JSON** - Can be directly imported into n8n
2. **Uses correct node types** - With proper typeVersion
3. **Has all connections** - Nodes are properly linked
4. **Includes all parameters** - Nothing missing
5. **Uses expressions correctly** - For dynamic values
6. **Has error handling** - IF nodes for success/failure paths

### Workflow Structure

```
┌─────────────────┐
│ Schedule Trigger│ ──┐
└─────────────────┘   │
                      ├──▶ ┌─────────────────┐
┌─────────────────┐   │    │ Read Token from │
│ Manual Trigger  │ ──┘    │ Airtable        │
└─────────────────┘        └────────┬────────┘
                                    │
                                    ▼
                           ┌─────────────────┐
                           │ HTTP Request    │
                           │ (Token Refresh) │
                           └────────┬────────┘
                                    │
                                    ▼
                           ┌─────────────────┐
                           │ IF: Refreshed?  │
                           └────────┬────────┘
                              │           │
                           TRUE        FALSE
                              │           │
                              ▼           ▼
                    ┌──────────────┐ ┌──────────────┐
                    │ Format Data  │ │ Mark Error   │
                    └──────┬───────┘ └──────┬───────┘
                           │                │
                           ▼                ▼
                    ┌──────────────┐ ┌──────────────┐
                    │ Save Tokens  │ │ Send Alert   │
                    └──────┬───────┘ └──────────────┘
                           │
                           ▼
                    ┌──────────────┐
                    │ Trigger Next │
                    │ Workflow     │
                    └──────────────┘
```

### JSON Output Requirements

```json
{
  "name": "Platform Token Refresh",
  "nodes": [
    {
      "parameters": { /* all parameters */ },
      "id": "uuid-here",
      "name": "Node Name",
      "type": "n8n-nodes-base.nodeType",
      "typeVersion": 1,
      "position": [x, y]
    }
  ],
  "connections": {
    "Node Name": {
      "main": [
        [
          {
            "node": "Next Node",
            "type": "main",
            "index": 0
          }
        ]
      ]
    }
  },
  "active": false,
  "settings": {
    "executionOrder": "v1"
  }
}
```

### Critical Requirements

1. **Airtable nodes** must use:
   - typeVersion: 2
   - Proper operation names (search, update, etc.)
   - Correct field references

2. **HTTP Request nodes** must include:
   - Full URL (not base + path separately unless using $env)
   - All headers
   - Proper content type
   - Body parameters in correct format

3. **IF nodes** must have:
   - Proper condition configuration
   - Both true and false outputs connected

4. **Error handling**:
   - Use "Continue on Fail" where appropriate
   - Check for error responses (not just HTTP errors)

5. **Expressions** use this format:
   - `{{ $json.field }}` for current node data
   - `{{ $node["Node Name"].json.field }}` for specific node data
   - `{{ $env.VARIABLE_NAME }}` for environment variables

---

## Example Prompt Usage

"Create an n8n workflow for LTK token rotation with:
- Schedule trigger every 8 hours
- Read tokens from Airtable base appABC123, table 'LTK_Tokens'
- POST to https://creator-auth.shopltk.com/oauth/token
- On success: save new tokens, trigger workflow 'Run LTK Reports' 
- On failure: mark error status, send Slack notification to #alerts"
```

---

## Template Variables

When generating workflows, the LLM should use these placeholders that you'll replace:

| Placeholder | Replace With |
|-------------|-------------|
| `{{AIRTABLE_BASE_ID}}` | Your actual base ID |
| `{{TABLE_NAME}}` | Your table name |
| `{{TOKEN_ENDPOINT}}` | Platform's token URL |
| `{{CLIENT_ID}}` | Platform client ID |
| `{{SLACK_WEBHOOK}}` | Your Slack webhook URL |
| `{{DOWNSTREAM_WORKFLOW_ID}}` | Workflow to trigger |

---

## Post-Generation Checklist

After generating the workflow JSON:

- [ ] Valid JSON (use jsonlint.com)
- [ ] All node IDs are unique UUIDs
- [ ] Connections reference correct node names
- [ ] typeVersions match current n8n version
- [ ] No hardcoded tokens/secrets
- [ ] Environment variables used for sensitive data
- [ ] Test with manual trigger first
- [ ] Check Airtable field names match exactly
