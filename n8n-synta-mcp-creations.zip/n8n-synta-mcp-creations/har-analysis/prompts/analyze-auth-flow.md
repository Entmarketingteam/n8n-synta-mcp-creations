# Analyze Auth Flow

**LLM Prompt for extracting authentication patterns from HAR files.**

---

## Usage

Paste this prompt along with the relevant HAR file contents (filtered for auth requests) to Claude or GPT.

---

## Prompt

```markdown
You are an expert at reverse-engineering web authentication flows. Analyze the following HAR file content and extract a complete authentication specification.

## HAR Content to Analyze

[PASTE HAR FILE CONTENT HERE - filter for auth-related requests first]

---

## Required Output

Provide a structured analysis with the following sections:

### 1. Authentication Type Classification

Identify which pattern this uses:
- **OAuth2 PKCE**: Look for code_verifier, code_challenge parameters
- **OAuth2 Standard**: Look for client_secret in token request
- **Session Cookie**: Look for Set-Cookie headers without OAuth endpoints
- **API Key**: Look for static Authorization headers or API key parameters

### 2. Key Endpoints

Extract and document each endpoint:

```yaml
endpoints:
  authorize:
    url: "https://..."
    method: GET
    parameters:
      - name: response_type
        value: code
        required: true
      - name: client_id
        value: "..."
        required: true
      # ... all parameters
  
  token:
    url: "https://..."
    method: POST
    content_type: application/x-www-form-urlencoded
    parameters:
      - name: grant_type
        values: [authorization_code, refresh_token]
        required: true
      # ... all parameters
  
  refresh:
    url: "https://..." # May be same as token endpoint
    method: POST
    # ... parameters for refresh
```

### 3. Token Specification

```yaml
token:
  format: JWT | opaque
  access_token:
    lifetime_seconds: 28800
    storage_location: header | cookie | body
  refresh_token:
    present: true | false
    rotates: true | false
    lifetime_seconds: 2592000
```

### 4. Required Headers

```yaml
headers:
  request:
    - name: Authorization
      format: "Bearer {access_token}"
    - name: Content-Type
      value: "application/json"
    # ... any custom headers
  
  response_to_capture:
    - name: Set-Cookie
      extract: ["session_id", "csrf_token"]
```

### 5. Special Requirements

Note any unusual requirements:
- PKCE code_verifier/challenge generation
- CSRF token handling
- Cookie domain/path requirements
- Custom request signing
- Rate limiting headers
- Required user-agent strings

### 6. n8n Workflow Specification

Provide a high-level workflow design:

```yaml
workflow:
  name: "[Platform] Token Refresh"
  triggers:
    - type: schedule
      cron: "0 */8 * * *"
    - type: manual
  
  nodes:
    - name: Read Token
      type: airtable
      operation: search
      
    - name: Refresh Token
      type: http_request
      method: POST
      url: "{{token_endpoint}}"
      # ... full config
      
    - name: Check Success
      type: if
      condition: "{{$json.access_token != undefined}}"
      
    # ... continue workflow design
```

### 7. Implementation Notes

- Initial auth requirements (browser needed?)
- Known gotchas or edge cases
- Recommended refresh schedule
- Error handling considerations

---

## Output Format

Please output the complete analysis as:

1. **Summary** (2-3 sentences describing the auth flow)
2. **YAML Specification** (all the structured data above)
3. **Curl Examples** (for testing manually)
4. **n8n HTTP Node Config** (ready to paste into n8n)
```

---

## Example Output

When you use this prompt with an LTK HAR file, you'd get something like:

```yaml
# LTK Authentication Specification

## Summary
LTK uses OAuth2 PKCE via Auth0 for authentication. Initial auth requires a browser
to complete the PKCE flow, but subsequent token refreshes can be automated via
HTTP requests. Tokens rotate on each refresh and expire after 8 hours.

## Endpoints
endpoints:
  token:
    url: "https://creator-auth.shopltk.com/oauth/token"
    method: POST
    content_type: application/x-www-form-urlencoded
    parameters:
      - name: grant_type
        value: refresh_token
        required: true
      - name: client_id
        value: "jGa..."
        required: true
      - name: refresh_token
        value: "{current_refresh_token}"
        required: true

## Token Specification
token:
  format: JWT
  access_token:
    lifetime_seconds: 28800
    storage_location: header
  refresh_token:
    present: true
    rotates: true
    lifetime_seconds: 2592000

## Curl Example
```bash
curl -X POST "https://creator-auth.shopltk.com/oauth/token" \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "grant_type=refresh_token" \
  -d "client_id=jGa..." \
  -d "refresh_token=v1.McH..."
```

## n8n HTTP Node Config
```json
{
  "method": "POST",
  "url": "https://creator-auth.shopltk.com/oauth/token",
  "authentication": "none",
  "contentType": "form-urlencoded",
  "bodyParameters": {
    "parameters": [
      {"name": "grant_type", "value": "refresh_token"},
      {"name": "client_id", "value": "={{$env.LTK_CLIENT_ID}}"},
      {"name": "refresh_token", "value": "={{$json.refresh_token}}"}
    ]
  }
}
```
```

---

## Tips for Better Results

1. **Filter the HAR first** - Remove image/CSS/JS requests, keep only API calls
2. **Include full request/response** - Headers and bodies are critical
3. **Note the sequence** - Order of requests matters for auth flows
4. **Highlight anomalies** - Mention anything unusual you noticed
