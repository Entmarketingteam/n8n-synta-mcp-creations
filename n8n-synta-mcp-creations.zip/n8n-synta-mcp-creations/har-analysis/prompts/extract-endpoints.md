# Extract API Endpoints

**LLM Prompt for discovering hidden API endpoints from HAR files.**

---

## Usage

After you've analyzed the auth flow, use this prompt to discover all the data endpoints a platform offers.

---

## Prompt

```markdown
You are an expert at discovering hidden APIs by analyzing network traffic. Review this HAR file and extract all usable API endpoints for data access.

## HAR Content to Analyze

[PASTE HAR FILE CONTENT HERE - this should be captured while browsing dashboard/reports pages]

---

## Required Output

### 1. API Overview

```yaml
api:
  base_url: "https://api.platform.com"
  version: "v1" | "v2" | null
  format: REST | GraphQL | mixed
  authentication:
    type: bearer | cookie | api_key
    header: "Authorization"
    format: "Bearer {access_token}"
```

### 2. Endpoint Catalog

For EACH discovered endpoint, document:

```yaml
endpoints:
  - name: "Get Analytics"
    description: "Fetches creator analytics/performance data"
    
    request:
      method: GET
      path: "/api/v1/creators/{creator_id}/analytics"
      
      path_params:
        - name: creator_id
          type: string
          description: "The creator's unique identifier"
          example: "abc123"
      
      query_params:
        - name: start_date
          type: date
          format: "YYYY-MM-DD"
          required: true
          example: "2024-01-01"
        - name: end_date
          type: date
          format: "YYYY-MM-DD"
          required: true
        - name: granularity
          type: enum
          values: [daily, weekly, monthly]
          default: daily
      
      headers:
        - name: Authorization
          value: "Bearer {access_token}"
          required: true
        - name: X-Platform-Version
          value: "2.0"
          required: false
    
    response:
      content_type: application/json
      structure:
        type: object
        properties:
          data:
            type: array
            items:
              type: object
              properties:
                date: { type: string, format: date }
                clicks: { type: integer }
                sales: { type: number }
                commission: { type: number }
          meta:
            type: object
            properties:
              total_records: { type: integer }
              page: { type: integer }
    
    example_response: |
      {
        "data": [
          {"date": "2024-01-01", "clicks": 150, "sales": 3, "commission": 45.00}
        ],
        "meta": {"total_records": 30, "page": 1}
      }
    
    rate_limit:
      requests_per_minute: 60
      header: "X-RateLimit-Remaining"
    
    pagination:
      type: offset | cursor | page
      param: "page"
      default_limit: 50
      max_limit: 100

  - name: "Get Commissions"
    # ... next endpoint
```

### 3. GraphQL Endpoints (if applicable)

```yaml
graphql:
  endpoint: "https://api.platform.com/graphql"
  
  queries:
    - name: "getCreatorStats"
      query: |
        query GetCreatorStats($creatorId: ID!, $dateRange: DateRangeInput!) {
          creatorStats(creatorId: $creatorId, dateRange: $dateRange) {
            totalClicks
            totalSales
            commission
          }
        }
      variables:
        - name: creatorId
          type: ID!
          example: "abc123"
        - name: dateRange
          type: DateRangeInput!
          example: {"start": "2024-01-01", "end": "2024-01-31"}
```

### 4. Data Models

Document the key data structures:

```yaml
models:
  Creator:
    properties:
      id: { type: string, description: "Unique identifier" }
      name: { type: string }
      email: { type: string }
      created_at: { type: datetime }
  
  Analytics:
    properties:
      date: { type: date }
      clicks: { type: integer }
      impressions: { type: integer }
      sales_count: { type: integer }
      sales_amount: { type: decimal }
      commission: { type: decimal }
  
  Commission:
    properties:
      id: { type: string }
      order_id: { type: string }
      product_name: { type: string }
      sale_amount: { type: decimal }
      commission_rate: { type: decimal }
      commission_amount: { type: decimal }
      status: { type: enum, values: [pending, approved, paid, cancelled] }
```

### 5. Endpoint Priority Matrix

Categorize by usefulness:

```yaml
priority:
  high:  # Most valuable for automation
    - "/api/v1/analytics" - Daily performance data
    - "/api/v1/commissions" - Earnings data
    - "/api/v1/products/top" - Top performing products
  
  medium:  # Nice to have
    - "/api/v1/profile" - Creator profile info
    - "/api/v1/links" - Link management
  
  low:  # Probably not needed
    - "/api/v1/notifications" - In-app notifications
    - "/api/v1/preferences" - User settings
```

### 6. Curl Examples

Provide ready-to-test curl commands:

```bash
# Get Analytics
curl -X GET "https://api.platform.com/api/v1/analytics?start_date=2024-01-01&end_date=2024-01-31" \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN" \
  -H "Content-Type: application/json"

# Get Commissions
curl -X GET "https://api.platform.com/api/v1/commissions?status=approved" \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN"
```

### 7. n8n Workflow Suggestions

```yaml
suggested_workflows:
  - name: "Daily Analytics Sync"
    schedule: "0 9 * * *"  # 9 AM daily
    endpoints_used:
      - GET /api/v1/analytics
    output: Google Sheet
    
  - name: "Weekly Commission Report"
    schedule: "0 10 * * 1"  # Monday 10 AM
    endpoints_used:
      - GET /api/v1/commissions
      - GET /api/v1/products/top
    output: Slack notification + Airtable
```
```

---

## Example: LTK Endpoints (Discovered)

```yaml
# LTK API Endpoints

api:
  base_url: "https://api-gateway.rewardstyle.com"
  version: "v1"
  format: REST
  authentication:
    type: bearer
    header: "Authorization"
    format: "Bearer {access_token}"

endpoints:
  - name: "Get Creator Analytics"
    request:
      method: GET
      path: "/api/v1/creators/{creator_id}/analytics"
      query_params:
        - name: start_date
          type: date
          format: "YYYY-MM-DD"
        - name: end_date
          type: date
          format: "YYYY-MM-DD"
    response:
      content_type: application/json
      
  - name: "Get Commissions"
    request:
      method: GET
      path: "/api/v1/creators/{creator_id}/commissions"
      query_params:
        - name: status
          type: enum
          values: [pending, approved, paid]
        - name: page
          type: integer
        - name: limit
          type: integer
          default: 50

  - name: "Get Top Products"
    request:
      method: GET
      path: "/api/v1/creators/{creator_id}/products/top"
      query_params:
        - name: time_period
          type: enum
          values: [7d, 30d, 90d, all_time]

priority:
  high:
    - GET /analytics - Daily performance tracking
    - GET /commissions - Earnings monitoring
  medium:
    - GET /products/top - Content optimization
```

---

## Tips

1. **Browse the full dashboard** - Load every page to capture all API calls
2. **Try different date ranges** - Some endpoints change based on filters
3. **Check network tab for XHR/Fetch** - Filter to only show API calls
4. **Look for GraphQL** - Modern apps often use GraphQL alongside REST
5. **Note pagination patterns** - Important for bulk data extraction
