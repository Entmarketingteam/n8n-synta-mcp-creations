# Authentication Patterns Guide

**Universal auth patterns for platforms without public APIs.**

---

## 🎯 The Big Picture

Most "no API" platforms actually have internal APIs. They all use one of these auth patterns:

```
┌─────────────────────────────────────────────────────────────────┐
│                    AUTH PATTERN DECISION TREE                   │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  Does the platform redirect to /oauth or /authorize?            │
│  │                                                              │
│  ├─ YES → OAuth2 Flow                                           │
│  │        │                                                     │
│  │        ├─ Has code_verifier in request? → OAuth2 PKCE        │
│  │        │  (LTK, modern mobile-first apps)                    │
│  │        │                                                     │
│  │        └─ No code_verifier? → OAuth2 Standard                │
│  │           (Google, Meta, TikTok)                             │
│  │                                                              │
│  └─ NO → Check for session cookies                              │
│          │                                                      │
│          ├─ Sets session_id or similar cookie? → Session Auth   │
│          │  (Amazon Associates, older platforms)                │
│          │                                                      │
│          └─ Uses Authorization header with static key? → API Key│
│             (Mavely, simple integrations)                       │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## 🔐 Pattern 1: OAuth2 PKCE

**Used by**: LTK, ShopMy, most modern apps

### How It Works

```
┌──────────┐     ┌──────────┐     ┌──────────┐
│  User    │────▶│  Browser │────▶│ Platform │
│          │     │  Auth    │     │ Auth0/   │
└──────────┘     └────┬─────┘     │ Cognito  │
                      │           └────┬─────┘
                      │                │
                      │  code + state  │
                      │◀───────────────┘
                      │
                      │  Exchange code for tokens
                      │  (with code_verifier)
                      ▼
               ┌──────────┐
               │ Tokens   │
               │ Received │
               └──────────┘
```

### Key Characteristics

- Initial auth requires browser (PKCE verification)
- Returns access_token + refresh_token
- Tokens typically expire in 1-24 hours
- Refresh tokens may rotate on each use
- **CAN be automated** after initial browser auth

### n8n Implementation

```
┌─────────────┐     ┌─────────────────┐     ┌─────────────┐
│ Schedule    │────▶│ Read Token from │────▶│ HTTP POST   │
│ Every 8hrs  │     │ Airtable        │     │ /oauth/token│
└─────────────┘     └─────────────────┘     └──────┬──────┘
                                                   │
                    ┌─────────────────┐            │
                    │ Token Refreshed?│◀───────────┘
                    └────────┬────────┘
                        │         │
                     TRUE       FALSE
                        │         │
                        ▼         ▼
               ┌──────────┐  ┌───────────────┐
               │ Save New │  │ Mark Error +  │
               │ Tokens   │  │ Alert         │
               └──────────┘  └───────────────┘
```

### Required Config

```json
{
  "platform": "ltk",
  "auth_type": "oauth2_pkce",
  "token_endpoint": "https://creator-auth.shopltk.com/oauth/token",
  "client_id": "jGa...",
  "grant_type": "refresh_token",
  "token_storage": {
    "type": "airtable",
    "base_id": "app...",
    "table_name": "Tokens"
  },
  "refresh_schedule": "0 */8 * * *"
}
```

### Template Location

```
auth-patterns/oauth2-pkce/
├── workflow.json         # n8n workflow template
├── README.md             # Pattern documentation
└── config-schema.json    # Required fields
```

---

## 🔐 Pattern 2: OAuth2 Standard

**Used by**: Google, Meta, TikTok, many enterprise APIs

### How It Works

Similar to PKCE but without code_verifier. Often uses client_secret instead.

```
POST /oauth/token
Content-Type: application/x-www-form-urlencoded

grant_type=refresh_token
&client_id=YOUR_CLIENT_ID
&client_secret=YOUR_SECRET
&refresh_token=YOUR_REFRESH_TOKEN
```

### Key Characteristics

- May require client_secret
- Refresh tokens often don't rotate
- Typically longer token lifetimes (1 hour - 1 day)
- Often requires approved OAuth app (developer portal)

### n8n Implementation

Same as PKCE pattern, but with client_secret in request.

### Required Config

```json
{
  "platform": "google",
  "auth_type": "oauth2_standard",
  "token_endpoint": "https://oauth2.googleapis.com/token",
  "client_id": "...",
  "client_secret": "...",
  "grant_type": "refresh_token",
  "scopes": ["analytics.readonly"]
}
```

### Template Location

```
auth-patterns/oauth2-standard/
├── workflow.json
├── README.md
└── config-schema.json
```

---

## 🔐 Pattern 3: Session Cookie

**Used by**: Amazon Associates, older platforms, admin panels

### How It Works

```
┌──────────┐     ┌──────────┐     ┌──────────┐
│ Browser  │────▶│  Login   │────▶│ Platform │
│ (Real)   │     │  Page    │     │ Server   │
└──────────┘     └────┬─────┘     └────┬─────┘
                      │                │
                      │  Set-Cookie:   │
                      │  session_id=...|
                      │◀───────────────┘
                      │
                      │  Use cookie for API calls
                      ▼
               ┌──────────┐
               │ API      │
               │ Access   │
               └──────────┘
```

### Key Characteristics

- **Requires real browser** (Browserbase/Playwright)
- Session cookies expire frequently (hours to days)
- Often includes CSRF token requirements
- May have 2FA/CAPTCHA challenges
- **Hardest to automate reliably**

### n8n Implementation

```
┌─────────────┐     ┌─────────────────┐     ┌─────────────┐
│ Schedule    │────▶│ Call Browserbase│────▶│ Run Login   │
│ Daily       │     │ API             │     │ Script      │
└─────────────┘     └─────────────────┘     └──────┬──────┘
                                                   │
                    ┌─────────────────┐            │
                    │ Extract Cookies │◀───────────┘
                    └────────┬────────┘
                             │
                             ▼
                    ┌─────────────────┐
                    │ Store in        │
                    │ Airtable        │
                    └─────────────────┘
```

### Required Config

```json
{
  "platform": "amazon_associates",
  "auth_type": "session_cookie",
  "login_url": "https://affiliate-program.amazon.com/signin",
  "browserbase": {
    "project_id": "...",
    "script_path": "platforms/amazon-associates/auth/session-refresh.js"
  },
  "cookies_needed": ["session-id", "session-token", "x-main"],
  "session_lifetime_hours": 24
}
```

### Browserbase Script Example

```javascript
// platforms/amazon-associates/auth/session-refresh.js
const { chromium } = require('playwright');

module.exports = async function refreshAmazonSession(credentials) {
  const browser = await chromium.connectOverCDP(process.env.BROWSERBASE_URL);
  const context = await browser.newContext();
  const page = await context.newPage();
  
  // Navigate to login
  await page.goto('https://affiliate-program.amazon.com/signin');
  
  // Fill credentials
  await page.fill('#ap_email', credentials.email);
  await page.fill('#ap_password', credentials.password);
  await page.click('#signInSubmit');
  
  // Wait for redirect (handle 2FA if needed)
  await page.waitForURL('**/home**', { timeout: 60000 });
  
  // Extract cookies
  const cookies = await context.cookies();
  const sessionCookies = cookies.filter(c => 
    ['session-id', 'session-token', 'x-main'].includes(c.name)
  );
  
  await browser.close();
  
  return sessionCookies;
};
```

### Template Location

```
auth-patterns/session-cookie/
├── workflow.json
├── browserbase-script.js
├── README.md
└── config-schema.json
```

---

## 🔐 Pattern 4: API Key

**Used by**: Mavely, simple integrations, internal tools

### How It Works

```
GET /api/v1/analytics
Authorization: Bearer YOUR_API_KEY
```

or

```
GET /api/v1/analytics?api_key=YOUR_API_KEY
```

### Key Characteristics

- Simplest pattern
- API key doesn't expire (or expires yearly)
- No refresh needed
- Often available in platform settings/dashboard
- **Easiest to automate**

### n8n Implementation

Just add the API key as a header or query param. No token refresh workflow needed!

### Required Config

```json
{
  "platform": "mavely",
  "auth_type": "api_key",
  "base_url": "https://api.mavely.com/v1",
  "auth_header": "Authorization",
  "auth_value": "Bearer ${API_KEY}"
}
```

### Template Location

```
auth-patterns/api-key/
├── workflow.json
├── README.md
└── config-schema.json
```

---

## 📊 Platform Comparison

| Platform | Auth Type | Refresh Needed | Browser Needed | Complexity |
|----------|-----------|----------------|----------------|------------|
| LTK | OAuth2 PKCE | Every 8 hours | Initial only | ⭐⭐⭐ |
| ShopMy | OAuth2 | TBD | Initial only | ⭐⭐⭐ |
| Mavely | API Key | Never | Never | ⭐ |
| Amazon | Session Cookie | Daily | Always | ⭐⭐⭐⭐⭐ |
| Google | OAuth2 Standard | Every hour | Never (if app approved) | ⭐⭐ |

---

## 🛠️ Building New Patterns

When you encounter a new auth type:

1. **Capture HAR** → See [HAR_ANALYSIS_GUIDE.md](HAR_ANALYSIS_GUIDE.md)
2. **Identify Pattern** → Use decision tree above
3. **Copy Template** → From `auth-patterns/[type]/`
4. **Customize** → Update endpoints and config
5. **Test** → In n8n test environment
6. **Document** → Add to `platforms/[name]/`

---

## ⚠️ Common Pitfalls

### OAuth2 PKCE
- ❌ Forgetting to store new refresh_token (tokens rotate!)
- ❌ Not handling token expiration during refresh
- ✅ Always overwrite both tokens atomically

### Session Cookie
- ❌ Assuming session lasts forever
- ❌ Not handling 2FA prompts
- ✅ Implement health checks and alerts

### API Key
- ❌ Committing API keys to git
- ✅ Always use environment variables

---

## 🔗 Related Docs

- [HAR Analysis Guide](HAR_ANALYSIS_GUIDE.md) - How to capture auth flows
- [Platform Registry](PLATFORM_REGISTRY.md) - All platforms and their configs
- [Deployment Guide](DEPLOYMENT_GUIDE.md) - Deploy via Synta MCP
