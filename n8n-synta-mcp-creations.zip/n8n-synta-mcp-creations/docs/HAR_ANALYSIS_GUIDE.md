# HAR Analysis Guide

**How to reverse-engineer any platform's authentication and API using HAR files.**

---

## 🎯 Overview

HAR (HTTP Archive) files capture all network traffic between your browser and a website. By analyzing these files, we can:

1. Discover hidden APIs that platforms use internally
2. Understand authentication flows (OAuth, PKCE, cookies, etc.)
3. Extract the exact request format needed to replicate calls
4. Build n8n workflows that automate these interactions

---

## 📥 Step 1: Capture the HAR File

### Chrome DevTools Method

1. Open Chrome DevTools (`F12` or `Cmd+Option+I`)
2. Go to **Network** tab
3. Check **Preserve log** (important!)
4. Clear existing logs (🚫 button)
5. Perform the action you want to capture:
   - For auth: Complete the full login flow
   - For data: Navigate to the dashboard/reports page
6. Right-click in the Network panel → **Save all as HAR with content**

### What to Capture

| Purpose | What to Do | File Name |
|---------|-----------|-----------|
| Initial Login | Full login from scratch | `platform-login.har` |
| Token Refresh | Let session expire, then refresh | `platform-refresh.har` |
| Data Fetch | Load dashboard/reports | `platform-data.har` |

---

## 🔍 Step 2: Analyze the HAR File

### Quick Analysis (Manual)

Open the HAR file in:
- **Chrome DevTools**: Drag .har file into Network tab
- **HAR Analyzer**: https://toolbox.googleapps.com/apps/har_analyzer/
- **VS Code**: Install "HAR Viewer" extension

### What to Look For

#### Authentication Endpoints

```
Look for requests to URLs containing:
- /auth/
- /oauth/
- /token
- /login
- /session
- /api/v1/auth
```

#### Key Headers

```
Authorization: Bearer eyJ...
X-CSRF-Token: abc123
Cookie: session_id=xyz
X-API-Key: ...
```

#### Request/Response Patterns

```json
// Token Refresh Request
POST /oauth/token
Content-Type: application/x-www-form-urlencoded

grant_type=refresh_token
&refresh_token=dGhpc2lz...
&client_id=abc123

// Token Refresh Response
{
  "access_token": "eyJhbGc...",
  "refresh_token": "bmV3cmVm...",
  "expires_in": 28800,
  "token_type": "Bearer"
}
```

---

## 🤖 Step 3: LLM-Assisted Analysis

Use this prompt with Claude/GPT to analyze HAR files:

### Auth Flow Analysis Prompt

```markdown
Analyze this HAR file and identify:

1. **Authentication Type**:
   - OAuth2 (standard, PKCE, or implicit)
   - Session cookie
   - API key
   - JWT
   - Other

2. **Key Endpoints**:
   - Login/authorize URL
   - Token endpoint
   - Refresh endpoint
   - User info endpoint

3. **Required Parameters**:
   - Client ID
   - Client Secret (if any)
   - Redirect URI
   - Scopes
   - Grant type

4. **Token Details**:
   - Token format (JWT, opaque)
   - Expiration time
   - Refresh mechanism

5. **Special Requirements**:
   - PKCE code_verifier/challenge
   - CSRF tokens
   - Cookie requirements
   - Custom headers

Output as structured JSON for n8n workflow generation.
```

### API Discovery Prompt

```markdown
Analyze this HAR file and extract all API endpoints:

1. **List all API calls** with:
   - Method (GET/POST/PUT/DELETE)
   - Full URL
   - Required headers
   - Request body format
   - Response structure

2. **Identify patterns**:
   - Base API URL
   - Authentication header format
   - Pagination patterns
   - Rate limiting indicators

3. **Categorize by function**:
   - Authentication
   - User data
   - Analytics/reports
   - Content/products

Output as a table with example curl commands.
```

---

## 📋 Step 4: Document the Pattern

### Auth Pattern Template

```markdown
# [Platform Name] Authentication

## Overview
- **Auth Type**: OAuth2 PKCE
- **Token Lifetime**: 8 hours
- **Refresh Method**: Refresh token rotation

## Endpoints
| Purpose | URL | Method |
|---------|-----|--------|
| Authorize | https://auth.platform.com/authorize | GET |
| Token | https://auth.platform.com/oauth/token | POST |
| Refresh | https://auth.platform.com/oauth/token | POST |

## Token Request
```http
POST /oauth/token HTTP/1.1
Host: auth.platform.com
Content-Type: application/x-www-form-urlencoded

grant_type=refresh_token
&client_id=YOUR_CLIENT_ID
&refresh_token=YOUR_REFRESH_TOKEN
```

## Required Headers
```
Authorization: Bearer {access_token}
Content-Type: application/json
X-Platform-Version: 2.0
```

## Notes
- Tokens rotate on each refresh
- Must store both access AND refresh tokens
- PKCE required for initial auth (browser needed)
```

---

## 🔧 Step 5: Generate n8n Workflow

### From Pattern to Workflow

Once you have the auth pattern documented, use this prompt:

```markdown
Create an n8n workflow JSON for token refresh with these specs:

**Platform**: [Platform Name]
**Token Endpoint**: [URL]
**Auth Type**: OAuth2 PKCE with refresh token rotation

**Workflow Requirements**:
1. Schedule trigger: Every 8 hours
2. Manual trigger: For testing
3. Read current tokens from Airtable
4. Make refresh request
5. IF success:
   - Format new tokens
   - Save to Airtable
   - Trigger downstream workflows
6. IF failure:
   - Mark status as error
   - Send alert notification

**Airtable Schema**:
- Table: Platform_Tokens
- Fields: platform, access_token, refresh_token, expires_at, status

Output complete n8n workflow JSON.
```

---

## 🗂️ Platform Analysis Checklist

Use this checklist when analyzing a new platform:

### Pre-Analysis
- [ ] Account created and verified
- [ ] Logged in at least once manually
- [ ] Know what data you want to extract

### HAR Capture
- [ ] Captured clean login flow (from logged out)
- [ ] Captured token refresh (if applicable)
- [ ] Captured data fetch requests
- [ ] Files saved with descriptive names

### Analysis
- [ ] Identified auth type
- [ ] Found token endpoint
- [ ] Found refresh mechanism
- [ ] Documented all required headers
- [ ] Found data API endpoints
- [ ] Noted rate limits/restrictions

### Documentation
- [ ] Created platform folder in repo
- [ ] Written auth/har-analysis.md
- [ ] Written data/endpoints.md
- [ ] Listed required env vars

### Implementation
- [ ] Created auth workflow JSON
- [ ] Tested refresh flow
- [ ] Added to Airtable config
- [ ] Scheduled automation

---

## ⚠️ Security Reminders

1. **Never commit HAR files** - They contain tokens!
2. **Add to .gitignore**:
   ```
   *.har
   har-analysis/samples/*
   !har-analysis/samples/.gitkeep
   ```
3. **Sanitize examples** - Remove real tokens from documentation
4. **Use environment variables** - Never hardcode credentials

---

## 🔗 Useful Tools

| Tool | Purpose | Link |
|------|---------|------|
| HAR Analyzer | Visual HAR inspection | https://toolbox.googleapps.com/apps/har_analyzer/ |
| jwt.io | Decode JWT tokens | https://jwt.io |
| Postman | Test API calls | https://postman.com |
| mitmproxy | Advanced traffic capture | https://mitmproxy.org |
| Browserbase | Headless browser for auth | https://browserbase.com |

---

## 📚 Example: LTK Analysis

### What We Discovered

1. **Auth Type**: OAuth2 PKCE via Auth0
2. **Token Endpoint**: `https://creator-auth.shopltk.com/oauth/token`
3. **Token Lifetime**: 8 hours (28800 seconds)
4. **Refresh**: Uses refresh_token grant type
5. **Special**: Tokens rotate on each refresh

### Key Request

```http
POST /oauth/token HTTP/1.1
Host: creator-auth.shopltk.com
Content-Type: application/x-www-form-urlencoded

grant_type=refresh_token
&client_id=jGa...
&refresh_token=v1.McH...
```

### Result

Working n8n workflow that refreshes tokens every 8 hours automatically, storing new tokens in Airtable and triggering report workflows on success.

---

## Next Steps

After analyzing a platform, proceed to:

1. **Generate Workflow** → Use templates in `auth-patterns/`
2. **Test Locally** → Import to n8n and test
3. **Document** → Add to `platforms/[name]/`
4. **Deploy** → Use Synta MCP for production
