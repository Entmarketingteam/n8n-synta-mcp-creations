# Platform Registry

**Central index of all affiliate platforms and their integration status.**

---

## 📊 Platform Overview

| Platform | Auth Type | Status | Refresh Schedule | Browser Needed | Priority |
|----------|-----------|--------|------------------|----------------|----------|
| LTK | OAuth2 PKCE | ✅ Working | Every 8 hours | Initial only | High |
| ShopMy | OAuth2 | 🔄 In Progress | TBD | Initial only | High |
| Mavely | TBD | 📋 Planned | TBD | TBD | High |
| Amazon Associates | Session Cookie | 📋 Planned | Daily | Always | Medium |

---

## 🏷️ LTK (LikeToKnow.it)

### Status: ✅ Working

### Overview
- **Company**: rewardStyle
- **Dashboard**: https://www.shopltk.com/creator
- **Auth Provider**: Auth0

### Authentication
```yaml
auth_type: oauth2_pkce
token_endpoint: "https://creator-auth.shopltk.com/oauth/token"
client_id: "jGa..." # Extracted from HAR
token_lifetime: 28800  # 8 hours
refresh_rotates: true
```

### Discovered Endpoints
| Endpoint | Method | Purpose |
|----------|--------|---------|
| `/api/v1/creators/{id}/analytics` | GET | Performance metrics |
| `/api/v1/creators/{id}/commissions` | GET | Earnings data |
| `/api/v1/creators/{id}/products/top` | GET | Top performing products |

### Repository Files
```
platforms/ltk/
├── README.md
├── auth/
│   ├── token-refresh.json      ✅ Deployed
│   ├── initial-auth.js         ✅ Working
│   └── har-analysis.md         ✅ Complete
├── data/
│   ├── get-analytics.json      🔄 In Progress
│   └── endpoints.md            ✅ Complete
└── config/
    ├── airtable-schema.json    ✅ Complete
    └── env-vars.md             ✅ Complete
```

### Environment Variables
```bash
LTK_CLIENT_ID=jGa...
LTK_AIRTABLE_BASE=appXXX
LTK_AIRTABLE_TABLE=LTK_Tokens
```

### n8n Workflows
- `LTK Token Rotation (Airtable)` - ID: a9gH2UthD2w239iv ✅
- `Run LTK Reports` - ID: 2Rr3f3YCgy3OIZ... ✅

---

## 🛍️ ShopMy

### Status: 🔄 In Progress

### Overview
- **Dashboard**: https://app.shopmy.us
- **Auth Provider**: TBD (likely custom OAuth2)

### Authentication
```yaml
auth_type: oauth2  # Suspected
token_endpoint: TBD
client_id: TBD
token_lifetime: TBD
```

### Progress
- [x] HAR file captured
- [ ] Auth flow analyzed
- [ ] Token refresh tested
- [ ] Endpoints documented
- [ ] Workflows created

### Repository Files
```
platforms/shopmy/
├── README.md                   📋 TODO
├── auth/
│   ├── token-refresh.json      📋 TODO
│   ├── initial-auth.js         🔄 Started
│   └── har-analysis.md         📋 TODO
├── data/
│   └── endpoints.md            📋 TODO
└── config/
    └── airtable-schema.json    📋 TODO
```

### Next Steps
1. Complete HAR analysis for auth flow
2. Test token refresh manually
3. Document API endpoints
4. Create n8n workflow

---

## 💰 Mavely

### Status: 📋 Planned

### Overview
- **Dashboard**: https://app.mavely.com (or similar)
- **Auth Provider**: Unknown

### Authentication
```yaml
auth_type: TBD  # Need to capture HAR
token_endpoint: TBD
```

### Progress
- [ ] HAR file captured
- [ ] Auth flow analyzed
- [ ] Token refresh tested
- [ ] Endpoints documented
- [ ] Workflows created

### Repository Files
```
platforms/mavely/
├── README.md                   📋 TODO
├── auth/
│   └── har-analysis.md         📋 TODO
├── data/
│   └── endpoints.md            📋 TODO
└── config/
```

### Notes
- Need to investigate if they have a simple API key option
- May be easier than OAuth2 platforms

---

## 🛒 Amazon Associates

### Status: 📋 Planned

### Overview
- **Dashboard**: https://affiliate-program.amazon.com
- **Auth Provider**: Amazon (proprietary)

### Authentication
```yaml
auth_type: session_cookie
login_url: "https://affiliate-program.amazon.com/signin"
session_lifetime: ~24 hours (varies)
mfa_required: Often
```

### Challenges
- ⚠️ No OAuth/API - requires browser automation
- ⚠️ Aggressive bot detection
- ⚠️ Mandatory 2FA for many accounts
- ⚠️ Session expires unpredictably

### Potential Solutions
1. **Browserbase persistent session** - Keep browser session alive
2. **Cookie extraction script** - Extract and store session cookies
3. **Email-based 2FA handling** - Parse 2FA codes from email
4. **Manual fallback** - Alert when re-auth needed

### Progress
- [ ] HAR file captured
- [ ] Session cookie flow documented
- [ ] Browserbase script created
- [ ] Cookie refresh automated
- [ ] Data extraction working

### Repository Files
```
platforms/amazon-associates/
├── README.md                   📋 TODO
├── auth/
│   ├── session-refresh.js      📋 TODO
│   ├── cookie-extractor.js     📋 TODO
│   └── har-analysis.md         📋 TODO
├── data/
│   └── endpoints.md            📋 TODO
└── config/
```

---

## 🔧 Configuration Templates

### Airtable Base Schema

All platforms should use this standard schema:

```
Base: Creator Dashboard Tokens

Table: Platform_Tokens
├── platform (Single Select): LTK, ShopMy, Mavely, Amazon
├── creator_id (Single Line Text)
├── access_token (Long Text)
├── refresh_token (Long Text)
├── expires_at (DateTime)
├── status (Single Select): active, error, expired, pending
├── last_refreshed (DateTime)
├── error_message (Long Text)
└── notes (Long Text)

Table: Platform_Config
├── platform (Single Select)
├── token_endpoint (URL)
├── client_id (Single Line Text)
├── refresh_schedule (Single Line Text): cron format
├── auth_type (Single Select): oauth2_pkce, oauth2, session, api_key
└── notes (Long Text)
```

### Environment Variables Template

```bash
# === LTK ===
LTK_CLIENT_ID=
LTK_CREATOR_ID=

# === ShopMy ===
SHOPMY_CLIENT_ID=
SHOPMY_CREATOR_ID=

# === Mavely ===
MAVELY_API_KEY=

# === Amazon ===
AMAZON_EMAIL=
AMAZON_PASSWORD=  # ⚠️ Use secure secrets manager

# === Shared ===
AIRTABLE_API_KEY=
AIRTABLE_BASE_ID=
SLACK_WEBHOOK_URL=
BROWSERBASE_API_KEY=
BROWSERBASE_PROJECT_ID=
```

---

## 📈 Roadmap

### Phase 1: Foundation (Current)
- [x] LTK token rotation working
- [x] Repo structure established
- [x] HAR analysis prompts created
- [ ] ShopMy integration complete
- [ ] Documentation finalized

### Phase 2: Expansion
- [ ] Mavely integration
- [ ] Amazon Associates (basic)
- [ ] Unified dashboard sync

### Phase 3: Polish
- [ ] Error monitoring dashboard
- [ ] Automated health checks
- [ ] Multi-creator support

---

## 🔗 Quick Links

| Resource | Link |
|----------|------|
| n8n Instance | https://entagency.app.n8n.cloud |
| Airtable Base | https://airtable.com/appXXX |
| Browserbase | https://browserbase.com |
| GitHub Repo | https://github.com/Entmarketingteam/n8n-synta-mcp-creations |
