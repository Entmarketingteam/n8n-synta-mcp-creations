# n8n-synta-mcp-creations

**Private library of reusable n8n components for affiliate platform automation.**

> ⚠️ **SECURITY NOTE**: This repo should be **PRIVATE**. It contains auth patterns, token endpoints, and automation scripts that could be misused if public.

---

## 🎯 Purpose

Build once, deploy everywhere. This repo contains:

1. **Auth Patterns** - Reusable OAuth2/PKCE/Cookie auth flows
2. **Platform Integrations** - LTK, ShopMy, Mavely, Amazon Associates
3. **n8n Workflows** - Ready-to-deploy workflow JSONs
4. **Browser Scripts** - Browserbase/Playwright scripts for complex auth
5. **HAR Analysis** - Tools to reverse-engineer platform APIs

---

## 📁 Repository Structure

```
n8n-synta-mcp-creations/
├── README.md
├── .env.example
├── .gitignore
│
├── 📚 docs/
│   ├── AUTH_PATTERNS.md          # Universal auth pattern documentation
│   ├── HAR_ANALYSIS_GUIDE.md     # How to capture & analyze HAR files
│   ├── PLATFORM_REGISTRY.md      # All platforms & their auth methods
│   └── DEPLOYMENT_GUIDE.md       # How to deploy via Synta MCP
│
├── 🔐 auth-patterns/
│   ├── oauth2-pkce/              # OAuth2 PKCE pattern (LTK-style)
│   │   ├── workflow.json         # n8n workflow template
│   │   ├── README.md             # Pattern documentation
│   │   └── config-schema.json    # Required config fields
│   │
│   ├── oauth2-standard/          # OAuth2 with refresh token
│   │   ├── workflow.json
│   │   ├── README.md
│   │   └── config-schema.json
│   │
│   ├── session-cookie/           # Cookie-based auth (Amazon-style)
│   │   ├── workflow.json
│   │   ├── browserbase-script.js
│   │   ├── README.md
│   │   └── config-schema.json
│   │
│   └── api-key/                  # Simple API key auth
│       ├── workflow.json
│       ├── README.md
│       └── config-schema.json
│
├── 🏢 platforms/
│   ├── ltk/
│   │   ├── README.md             # Platform overview & endpoints
│   │   ├── auth/
│   │   │   ├── token-refresh.json      # Token refresh workflow
│   │   │   ├── initial-auth.js         # Browserbase initial auth
│   │   │   └── har-analysis.md         # HAR file analysis notes
│   │   ├── data/
│   │   │   ├── get-analytics.json      # Analytics fetch workflow
│   │   │   ├── get-commissions.json    # Commission data workflow
│   │   │   └── endpoints.md            # Discovered API endpoints
│   │   └── config/
│   │       ├── airtable-schema.json    # Airtable table structure
│   │       └── env-vars.md             # Required environment vars
│   │
│   ├── shopmy/
│   │   ├── README.md
│   │   ├── auth/
│   │   │   ├── token-refresh.json
│   │   │   ├── initial-auth.js
│   │   │   └── har-analysis.md
│   │   ├── data/
│   │   │   └── endpoints.md
│   │   └── config/
│   │       └── airtable-schema.json
│   │
│   ├── mavely/
│   │   ├── README.md
│   │   ├── auth/
│   │   │   └── har-analysis.md
│   │   ├── data/
│   │   │   └── endpoints.md
│   │   └── config/
│   │
│   └── amazon-associates/
│       ├── README.md
│       ├── auth/
│       │   ├── session-refresh.js      # Browserbase session script
│       │   ├── cookie-extractor.js
│       │   └── har-analysis.md
│       ├── data/
│       │   └── endpoints.md
│       └── config/
│
├── 🔧 utilities/
│   ├── notifications/
│   │   ├── slack-notify.json           # Slack notification sub-workflow
│   │   ├── discord-notify.json
│   │   └── email-notify.json
│   │
│   ├── storage/
│   │   ├── drive-upload.json           # Google Drive upload
│   │   ├── airtable-log.json           # Log to Airtable
│   │   └── sheet-append.json           # Append to Google Sheet
│   │
│   ├── error-handling/
│   │   ├── retry-wrapper.json          # Retry with backoff
│   │   ├── error-notifier.json         # Error notification
│   │   └── dead-letter-queue.json      # Failed job tracking
│   │
│   └── triggers/
│       ├── slack-intake.json           # Slack message trigger
│       ├── webhook-auth.json           # Authenticated webhook
│       └── schedule-lock.json          # Prevent overlap
│
├── 🧪 har-analysis/
│   ├── README.md                       # How to use HAR analyzer
│   ├── prompts/
│   │   ├── analyze-auth-flow.md        # LLM prompt for auth analysis
│   │   ├── extract-endpoints.md        # LLM prompt for API discovery
│   │   └── generate-workflow.md        # LLM prompt for n8n generation
│   ├── samples/
│   │   └── .gitkeep                    # HAR files go here (gitignored)
│   └── outputs/
│       └── .gitkeep                    # Analysis outputs
│
├── 📜 scripts/
│   ├── har-to-workflow.js              # HAR analysis script
│   ├── validate-workflow.js            # Workflow JSON validator
│   ├── deploy-to-n8n.js                # Deploy workflow via API
│   └── sync-airtable-config.js         # Sync platform configs
│
├── 🎨 .cursor/
│   └── rules/
│       ├── n8n-workflow.mdc            # n8n workflow generation rules
│       ├── har-analysis.mdc            # HAR analysis rules
│       └── auth-patterns.mdc           # Auth pattern rules
│
└── 📋 workflows/
    ├── complete/                       # Full production workflows
    │   ├── ltk-token-rotation.json
    │   ├── ltk-analytics-sync.json
    │   └── unified-dashboard.json
    │
    └── templates/                      # Starting point templates
        ├── token-refresh-template.json
        ├── data-sync-template.json
        └── error-handler-template.json
```

---

## 🚀 Quick Start

### 1. Analyze a New Platform

```bash
# 1. Capture HAR file from browser DevTools
# 2. Save to har-analysis/samples/platform-name.har

# 3. Run analysis (uses LLM prompt)
node scripts/har-to-workflow.js samples/mavely-login.har

# 4. Review generated files in har-analysis/outputs/
```

### 2. Deploy a Workflow

```bash
# Using Synta MCP in Claude/Cursor:
"Deploy the LTK token refresh workflow from my repo"

# Or via script:
node scripts/deploy-to-n8n.js platforms/ltk/auth/token-refresh.json
```

### 3. Add a New Platform

1. Create folder: `platforms/[platform-name]/`
2. Capture HAR file of login flow
3. Run HAR analysis to extract auth pattern
4. Generate workflow from auth-patterns template
5. Test and commit

---

## 🔐 Auth Pattern Matrix

| Platform | Auth Type | Token Refresh | Browser Needed | Status |
|----------|-----------|---------------|----------------|--------|
| LTK | OAuth2 PKCE | ✅ 8 hours | Initial only | ✅ Working |
| ShopMy | OAuth2 | ✅ TBD | Initial only | 🔄 In Progress |
| Mavely | TBD | TBD | TBD | 📋 Planned |
| Amazon | Session Cookie | ⚠️ Complex | Always | 📋 Planned |

---

## 📖 Documentation

- [Auth Patterns Guide](docs/AUTH_PATTERNS.md) - Deep dive into each auth type
- [HAR Analysis Guide](docs/HAR_ANALYSIS_GUIDE.md) - How to reverse-engineer APIs
- [Platform Registry](docs/PLATFORM_REGISTRY.md) - All platforms & their configs
- [Deployment Guide](docs/DEPLOYMENT_GUIDE.md) - Deploy via Synta MCP

---

## ⚠️ Security Notes

1. **Never commit**:
   - `.env` files with real credentials
   - HAR files (contain tokens!)
   - Access/refresh tokens
   
2. **Always use**:
   - Airtable for token storage (encrypted)
   - Environment variables for secrets
   - `.gitignore` properly configured

---

## 🔄 Workflow Lifecycle

```
┌─────────────────────────────────────────────────────────────────┐
│                    COMPONENT LIFECYCLE                          │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  1. CAPTURE          2. ANALYZE           3. GENERATE          │
│  ┌──────────┐       ┌──────────┐        ┌──────────┐          │
│  │ Browser  │──────▶│ HAR File │───────▶│ LLM      │          │
│  │ DevTools │       │ Analysis │        │ Prompts  │          │
│  └──────────┘       └──────────┘        └──────────┘          │
│                                                │                │
│                                                ▼                │
│  6. DEPLOY           5. TEST             4. STORE             │
│  ┌──────────┐       ┌──────────┐        ┌──────────┐          │
│  │ Synta    │◀──────│ n8n      │◀───────│ GitHub   │          │
│  │ MCP      │       │ Instance │        │ Repo     │          │
│  └──────────┘       └──────────┘        └──────────┘          │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```
