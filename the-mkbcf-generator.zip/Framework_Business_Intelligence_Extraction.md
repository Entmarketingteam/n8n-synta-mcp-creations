# Framework: Business Intelligence Extraction

**Version:** 1.0  
**Last Updated:** November 2025  
**Purpose:** Structured protocols for extracting comprehensive business intelligence through Socratic dialogue  
**Referenced By:** Expert 0 - MKBCF Creator

---

## Overview

This framework provides systematic question sequences, progressive deepening techniques, and validation criteria for extracting actionable business intelligence. Designed for AI agents conducting structured business intelligence interviews to populate MKBCF (Marketing Knowledge Base Context File).

**Core Principles:**
- Socratic method: Elicit latent knowledge through targeted questioning
- Progressive deepening: Start broad, narrow based on responses
- Data specificity: No generic descriptors or vague statements
- Efficiency: Extract sufficient depth in 2-4 exchanges maximum

---

## Domain 1: Business Intelligence Extraction

### Initial Assessment Questions

**Business Model Foundation (First Exchange):**
1. "Describe your business in 2-3 sentences: What do you sell, to whom, and how do you make money?"
2. "What's your current monthly/annual revenue, or revenue stage if pre-revenue?" (Provide ranges: $0-50k, $50k-150k, $150k-500k, $500k+)
3. "How many products or service tiers do you offer, and what are the price points?"

**Purpose:** Establish foundational context, identify business model type, assess revenue maturity.

### Progressive Deepening Sequences

**If Response Lacks Clarity on Business Model:**
- "Walk me through a typical customer transaction from start to finish."
- "What does the customer receive, and what do they pay?"
- "Is this B2B, B2C, D2C, marketplace, SaaS, or another model?"

**For Product/Service Portfolio:**
- "For each offering, what's the specific customer outcome or problem solved?"
- "What's included at each price point? Break down the value stack."
- "Which offering generates the most revenue? Which has the best margins?"

**For Competitive Differentiation:**
- "If a customer is comparing you to [top 3 competitors], what makes you different?"
- "What can you do/deliver that competitors cannot?"
- "What would your best customer say makes you worth the premium/worth switching?"

### Specificity Triggers

**Red Flags (Insufficient Depth):**
- "We offer quality products/services" → Ask: "Define quality in measurable terms. What does quality mean in your specific context?"
- "We provide great customer service" → Ask: "What does your customer service include that's different? Give 3 specific examples."
- "We're the best in [category]" → Ask: "Best by what metric? Market share? Customer satisfaction score? Retention rate?"

**Depth Benchmarks (Sufficient):**
- Business model is clear in ≤3 sentences
- Products/services include specific features, benefits, and pricing
- Differentiation cites specific capabilities, not generic attributes
- Constraints are quantified (budget in dollars, team size in FTEs, timeline in months)

### Constraint Identification

**Critical Questions:**
1. "What's your total marketing budget for this campaign/period?"
2. "How many people will execute marketing activities? What are their skill levels?"
3. "What tools, platforms, or systems do you currently use or have access to?"
4. "What can you NOT do? (Regulatory constraints, competitive agreements, technical limitations)"

**Common Constraints to Probe:**
- Budget limitations (absolute dollar cap, CAC cap, ROAS requirement)
- Time constraints (launch deadlines, seasonal windows)
- Technical constraints (no developer resources, platform limitations)
- Team constraints (solo founder, outsourced execution)
- Regulatory/compliance (healthcare, finance, legal restrictions)

---

## Domain 2: Strategic Context Extraction

### Objective Definition Questions

**Primary Goals (First Exchange):**
1. "What's your #1 business objective for the next 3-12 months?"
2. "What metric defines success? (Revenue, customers, MRR, market share, etc.)"
3. "What's the quantified target? By when?"

**Purpose:** Establish clear, measurable objectives that marketing will support.

### Progressive Deepening Sequences

**If Objective is Vague ("grow the business"):**
- "Grow by how much? 20%? 2x? 10x?"
- "Grow what specifically? Revenue, customers, market share, brand awareness?"
- "Why this objective, why now? What happens if you don't achieve it?"

**For Timeline Clarification:**
- "What's driving this timeline? (Market window, funding runway, competitive pressure)"
- "What milestones must hit along the way?"
- "What's the consequence of delay?"

**For Success Metrics:**
- "How will you measure progress week-to-week?"
- "What leading indicators predict achievement of this goal?"
- "What's the minimum acceptable outcome vs. stretch goal?"

### Strategic Constraint Mapping

**Risk Tolerance Assessment:**
1. "On a scale of 1-10, how much risk/experimentation can you tolerate? (1=proven tactics only, 10=willing to test unproven channels)"
2. "What's your runway before you MUST see results? (Weeks, months, quarters)"
3. "Have you tried marketing before? What happened?"

**Resource Allocation:**
- "If you had to allocate $100 across different marketing activities, how would you split it?"
- "What are you willing to cut to fund marketing growth?"
- "What internal resources can you leverage? (Email lists, content, partnerships, owned media)"

### Depth Benchmarks

**Sufficient Strategic Context Includes:**
- Objective is quantified (not "increase revenue" but "add $50k MRR")
- Timeline is specific (Q1 2025, not "soon")
- Success metrics are defined and measurable
- Constraints are explicit (budget, team, time, risk tolerance)
- Strategic rationale is clear (why this goal, why now)

---

## Domain 3: Brand Identity Extraction

### Voice and Tone Elicitation

**Initial Assessment:**
1. "How do you describe your brand to customers right now? Show me your best marketing copy or website description."
2. "If your brand were a person, what 3-5 adjectives describe their personality?"
3. "What tone do you use? (Formal/casual, technical/accessible, serious/playful)"

**Purpose:** Move beyond generic "professional" to capture actual brand voice characteristics.

### Progressive Deepening Sequences

**For Voice Characteristics:**
- "Show me an example of messaging that feels on-brand vs. off-brand."
- "Read these two versions [provide contrast examples]. Which sounds like you?"
- "What words or phrases do you use frequently in customer communication?"

**For Messaging Guidelines:**
- "What topics or themes are core to your brand? (Innovation, reliability, empowerment, etc.)"
- "What should your brand NEVER say? What associations do you avoid?"
- "How do you want customers to feel after interacting with your brand?"

**For Aspirational vs. Current State:**
- "Is your current brand voice where you want it to be, or are you evolving?"
- "If evolving, what are you moving from and moving toward?"
- "What brand do you admire and want to emulate? Why?"

### Brand Voice Validation Framework

**Test Questions:**
- "If I wrote 'Leverage synergistic solutions to optimize outcomes,' is that on-brand?" (Tests for jargon tolerance)
- "If I wrote 'Stop wasting time on [problem]. Here's the fix,' is that on-brand?" (Tests for directness)
- "If I wrote 'Let's crush your goals together 🚀,' is that on-brand?" (Tests for enthusiasm level and emoji use)

**Extract Specific Do's and Don'ts:**
- ✅ Use: [Industry terms they embrace, tone characteristics, messaging themes]
- ❌ Avoid: [Corporate speak they reject, competitor associations, clichés]

### Depth Benchmarks

**Sufficient Brand Identity Includes:**
- Voice described with 3-5 specific adjectives (not generic "professional")
- Tone is clear across formality, technicality, and emotion axes
- User can provide examples of on-brand vs. off-brand messaging
- Core messaging pillars identified (3-5 themes)
- Explicit do's and don'ts documented

---

## Domain 4: Audience Intelligence Extraction

### ICP Definition Framework

**Demographic/Firmographic Foundation:**

**B2B Questions:**
1. "What company size do you target? (Employees, revenue, or stage: startup, growth, enterprise)"
2. "What industries or verticals?"
3. "What job titles/roles make the buying decision?"
4. "What regions/geographies?"

**B2C Questions:**
1. "What age range, gender, income level?"
2. "What life stage? (Student, young professional, parent, retiree)"
3. "What location/geography?"
4. "What other demographic factors matter? (Education, occupation, lifestyle)"

**Purpose:** Establish targetable ICP for ad platforms and content strategy.

### Psychographic Extraction Protocol

**Pain Points and Motivations:**
1. "What keeps your ideal customer up at night? What problem causes them daily frustration?"
2. "What have they tried before that failed? Why?"
3. "What outcome are they desperate to achieve?"

**Values and Beliefs:**
- "What does your customer believe about [problem space]?"
- "What do they value most? (Speed, reliability, status, savings, innovation)"
- "What fears or objections prevent them from buying?"

**Customer Journey Mapping:**
1. "How aware is your customer of their problem? (Unaware, problem-aware, solution-aware, product-aware)"
2. "What triggers them to start looking for a solution?"
3. "Who influences the decision? (Individual, team, spouse, advisor)"
4. "How long is the decision cycle? (Impulse, days, weeks, months)"

### Decision Criteria Extraction

**Purchase Drivers:**
1. "When comparing options, what matters MOST to your customer?" (Rank: Price, features, brand, support, ease of use, etc.)
2. "What would make them choose you over a competitor?"
3. "What would make them NOT choose you? (Common objections)"

**Buying Process:**
- "Do they buy on first interaction, or is there a nurture cycle?"
- "What information do they need before purchase?"
- "What final objection must be overcome to close?"

### Depth Benchmarks

**Sufficient Audience Intelligence Includes:**
- ICP is specific enough to target with ads (not "small businesses" but "10-50 employee B2B SaaS companies in US/Canada")
- Pain points articulated in customer language (direct quotes preferred)
- Decision criteria are prioritized (not just listed)
- Awareness level identified for messaging strategy
- Objections are specific and addressable

---

## Domain 5: Historical Performance Extraction

### Current State Assessment

**Existing Marketing Activities:**
1. "What marketing are you doing right now? (Channels, frequency, investment)"
2. "What's working? What metrics prove it?"
3. "What's not working? Why do you think it failed?"

**Purpose:** Understand baseline, identify quick wins, avoid repeating failures.

### Historical Campaign Analysis

**If User Has Marketing History:**
1. "Describe your best performing campaign. What made it successful?"
2. "What did you try that completely failed? What was the hypothesis and why did it fail?"
3. "What channels have you tested? (Paid ads, SEO, email, social, partnerships, etc.)"
4. "What are your current CAC, LTV, conversion rates, if known?"

**If User Has NO Marketing History:**
- "How do you currently acquire customers? (Referrals, word-of-mouth, direct sales)"
- "What organic channels exist? (Website traffic, social following, email list)"
- "What assets do you have? (Content, video, case studies, testimonials)"

### Competitive Landscape Mapping

**Competitive Intelligence:**
1. "Who are your top 3 competitors? What's their market positioning?"
2. "What marketing tactics are they using that you've observed?"
3. "What are they known for? What's their differentiation claim?"
4. "Where do they show up? (Google ads, trade shows, podcasts, partnerships)"

**Market Positioning:**
- "In your market, what categories exist? (e.g., Premium, Budget, Feature-Rich, Simple)"
- "Where do you fit? Where do you WANT to be perceived?"
- "What market position is underserved?"

### Asset Inventory Protocol

**Existing Marketing Assets:**
- Website: Traffic, conversion rate, key pages
- Email list: Size, engagement rate, segmentation
- Content: Blog posts, videos, case studies, whitepapers
- Social media: Platforms, follower counts, engagement rates
- Creative assets: Photos, videos, graphics, brand guidelines
- Customer data: Testimonials, case studies, referral sources

**Technical Infrastructure:**
- CRM/ESP: (HubSpot, Mailchimp, etc.)
- Analytics: (Google Analytics, Mixpanel, etc.)
- Ad platforms: (Google Ads, Facebook Ads accounts)
- Other tools: (SEO, landing page builders, etc.)

### Depth Benchmarks

**Sufficient Historical Context Includes:**
- Current marketing activities documented with metrics (not "we do social media" but "Post 5x/week on LinkedIn, avg 200 views, 2% engagement")
- Past wins and failures include specific hypotheses and outcomes
- Competitive landscape includes 3-5 competitors with positioning
- Asset inventory is comprehensive with quantified metrics
- Technical infrastructure documented (enables tactical execution planning)

**If No History Exists:**
- Documented as "Pre-Marketing Stage"
- Organic/referral channels identified
- Competitive intelligence captured independently
- Asset inventory still required (website, content, existing brand materials)

---

## Progressive Deepening Techniques

### When Responses Lack Specificity

**Generic Response Pattern:**
User says: "We're focused on quality and customer service."

**Deepening Protocol:**
1. Acknowledge: "Quality and service are important. Help me understand what that means specifically for you."
2. Probe: "What does quality mean in measurable terms for your customers?"
3. Example: "For instance, is it speed? Accuracy? Customization? Give me 2-3 concrete examples."
4. Compare: "How is your 'quality' different from a competitor's?"

**Generic Response Pattern:**
User says: "We target small businesses."

**Deepening Protocol:**
1. Quantify: "Small by what metric? Employees? Revenue? What's the range?"
2. Narrow: "What industries or verticals?"
3. Specify: "Who in those businesses makes the buying decision? What's their title?"
4. Context: "In what geography? Any other constraints?"

### When Users Provide Vague Objectives

**Vague Objective:**
"We want to grow."

**Deepening Protocol:**
1. Quantify: "Grow by how much? 20%? Double?"
2. Specify: "Grow what specifically? Revenue, customers, market share?"
3. Timeline: "By when?"
4. Rationale: "What's driving this growth goal right now?"

### Handling User Fatigue

**Signals of Fatigue:**
- Responses get progressively shorter
- User says "I don't know" more frequently
- User asks "How much longer?"
- User provides lists instead of depth

**Protocol:**
1. Acknowledge: "I know this is thorough. We're covering a lot to build a strong foundation."
2. Consolidate: "Let me ask the 3-4 most important remaining questions in one go."
3. Prioritize: Focus on domains with biggest gaps
4. Accept: Proceed with available data depth, flag suboptimal areas in MKBCF

---

## Red Flags: Insufficient Data Depth

### Business Model Red Flags
- ❌ "We sell [product category]" → Insufficient: Need specific product, price, and value prop
- ❌ Revenue stated as range without context → Need: "Where in range, trend direction, timeframe"
- ❌ "We're B2B" → Insufficient: Need target company size, decision-maker, industry

### Strategic Context Red Flags
- ❌ "We want more customers" → Insufficient: Need quantified target, timeline, success metrics
- ❌ "As soon as possible" for timeline → Insufficient: Need specific date/period, rationale
- ❌ No mentioned constraints → Probe explicitly, constraints always exist

### Brand Identity Red Flags
- ❌ "Professional tone" → Insufficient: Need 3-5 specific adjectives, examples
- ❌ No messaging do's/don'ts → Brand voice is undifferentiated
- ❌ "Like [competitor]" without further detail → Need what specifically to emulate

### Audience Red Flags
- ❌ "Everyone" or "small businesses" → Insufficient: Need specific ICP parameters
- ❌ Generic pain points ("too expensive," "takes too long") → Need customer language, specific context
- ❌ No objections mentioned → Always exist, probe explicitly

### Historical Performance Red Flags
- ❌ "We haven't tried marketing yet" without documenting organic acquisition → Need referral sources, word-of-mouth mechanics
- ❌ "We did Facebook ads, didn't work" without metrics/hypothesis → Need: Spend, impressions, CTR, hypothesis for failure
- ❌ No competitive intelligence → Always exists, probe for market awareness

---

## Validation Criteria by Domain

### Business Intelligence Validation
✅ Business model clear in ≤3 sentences  
✅ Product/service portfolio with specific pricing documented  
✅ Differentiation cites specific capabilities (not generic "quality")  
✅ Constraints quantified (dollars, FTEs, weeks, platform limits)  
✅ Revenue stage identified with context

### Strategic Context Validation
✅ Objective is quantified (not "grow" but "add $50k MRR")  
✅ Timeline is specific (Q1 2025, not "soon")  
✅ Success metrics defined and measurable  
✅ Risk tolerance assessed (scale 1-10)  
✅ Strategic rationale documented

### Brand Identity Validation
✅ Voice described with 3-5 specific adjectives  
✅ User can distinguish on-brand vs. off-brand examples  
✅ Core messaging pillars identified (3-5 themes)  
✅ Explicit do's and don'ts documented  
✅ Tone clear across formality, technicality, emotion

### Audience Intelligence Validation
✅ ICP specific enough for ad targeting  
✅ Pain points in customer language  
✅ Decision criteria prioritized  
✅ Awareness level identified  
✅ Objections are specific

### Historical Performance Validation
✅ Current channels documented with metrics  
✅ Past campaigns analyzed (wins and failures with hypotheses)  
✅ Competitive landscape mapped (3-5 competitors)  
✅ Asset inventory comprehensive with metrics  
✅ If no history: "Pre-Marketing Stage" documented with rationale

---

## Common Extraction Pitfalls

### Pitfall 1: Accepting Generic Answers
**Problem:** User says "We have great customer service" and agent moves on.  
**Fix:** Always ask for 2-3 specific examples, measurable dimensions, or comparisons.

### Pitfall 2: Skipping Constraint Identification
**Problem:** No documented budget, time, or resource constraints.  
**Fix:** Explicitly ask constraint questions even if user doesn't volunteer.

### Pitfall 3: Vague ICP Definition
**Problem:** "We target small businesses" documented as-is.  
**Fix:** Probe for quantified firmographics, industries, decision-makers.

### Pitfall 4: No Historical Data for Mature Businesses
**Problem:** User claims no marketing history, but has been in business 5+ years.  
**Fix:** Probe for organic channels, referral sources, any past attempts (even informal).

### Pitfall 5: Insufficient Brand Voice Depth
**Problem:** "Professional" documented as brand voice.  
**Fix:** Use test questions ("Is X phrase on-brand?") to elicit specificity.

### Pitfall 6: Missing Competitive Context
**Problem:** No competitive landscape documented.  
**Fix:** Even if user claims "no competitors," probe for alternatives customers consider.

---

## Efficiency Protocols

### Two-Exchange Extraction (High Clarity Users)

**Exchange 1:** Business model + strategic objectives + constraints  
**Exchange 2:** Brand + ICP + historical performance

**Consolidation Strategy:**
- Group related questions by domain
- Present 4-6 questions per exchange
- Use bullet format for easy response

### Three-Exchange Extraction (Moderate Clarity Users)

**Exchange 1:** Business intelligence + strategic context  
**Exchange 2:** Brand identity + audience intelligence  
**Exchange 3:** Historical performance + validation/gap-filling

### Four-Exchange Extraction (Low Clarity/Exploratory Users)

**Exchange 1:** Business model foundations  
**Exchange 2:** Strategic objectives + brand voice  
**Exchange 3:** Audience intelligence + competitive landscape  
**Exchange 4:** Historical context + final validation

**Maximum:** Never exceed 4 exchanges. If user cannot provide sufficient data after 4 exchanges, document gaps explicitly in MKBCF and proceed.

---

## Cross-References

- **MKBCF_Template.md:** Structure requirements and section definitions for extracted intelligence
- **Optimized_UEF_Framework.md:** Strategic planning context (used by Expert 1, informs strategic objective extraction)
- **THE_HYBRID_REVENUE_ENGINE.md:** Revenue velocity model (used by Expert 1, informs channel and budget extraction)

---

## Changelog

**v1.0 (November 2025):** Initial framework creation for Marketer Lab Expert 0 deployment
